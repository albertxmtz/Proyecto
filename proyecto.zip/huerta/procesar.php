<?php
// procesar.php
//
// Inserta el cultivo en la BD.
// Se llama desde nuevo.php, que ya validó y creó $nombre, $tipo, $dias_cosecha.

// Evitar acceso directo
if (!isset($nombre, $tipo, $dias_cosecha)) {
    header('Location: nuevo.php?error=' . urlencode('Acceso no válido al formulario.'));
    exit;
}

require_once __DIR__ . '/config/db.php';

// Sentencia preparada para el INSERT
$sql = "INSERT INTO cultivos (nombre, tipo, dias_cosecha) VALUES (?, ?, ?)";
$stmt = mysqli_prepare($conexion, $sql);

if (!$stmt) {
    error_log('Error al preparar INSERT de cultivos: ' . mysqli_error($conexion));
    header('Location: nuevo.php?error=' . urlencode('No se pudo guardar el cultivo.'));
    exit;
}

// "ssi" → string, string, integer
mysqli_stmt_bind_param($stmt, 'ssi', $nombre, $tipo, $dias_cosecha);

if (!mysqli_stmt_execute($stmt)) {
    error_log('Fallo al ejecutar INSERT de cultivos: ' . mysqli_stmt_error($stmt));
    header('Location: nuevo.php?error=' . urlencode('No se pudo guardar el cultivo.'));
    exit;
}

mysqli_stmt_close($stmt);
mysqli_close($conexion);

// PRG: redirigimos al listado con mensaje
header('Location: index.php?mensaje=' . urlencode('Cultivo guardado correctamente.'));
exit;
