<?php
require_once __DIR__ . '/logic/cultivos.php';

$errores = [];
$nombre = '';
$tipo = '';
$dias_cosecha = '';

// Si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recuperamos y saneamos los campos
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $tipo = filter_input(INPUT_POST, 'tipo', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $dias_cosecha = filter_input(INPUT_POST, 'dias_cosecha', FILTER_VALIDATE_INT);

    // --- VALIDACIONES ---

    // Nombre obligatorio
    if ($nombre === null || $nombre === '') {
        $errores['nombre'] = 'El nombre es obligatorio.';
    }

    // Tipo válido usando esTipoValido()
    if ($tipo === null || $tipo === '' || !esTipoValido($tipo)) {
        $errores['tipo'] = 'Debes seleccionar un tipo válido.';
    }

    // Días de cosecha: entero positivo
    if ($dias_cosecha === false || $dias_cosecha === null || $dias_cosecha < 0) {
        $errores['dias_cosecha'] = 'Los días de cosecha deben ser un número entero positivo.';
    }

    // Si no hay errores, delegamos el INSERT a procesar.php
    if (empty($errores)) {
        require __DIR__ . '/procesar.php';
        exit;
    }
}

// Mensaje de error genérico que pueda venir de procesar.php
$mensajeError = filter_input(INPUT_GET, 'error', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nuevo cultivo</title>
    <style>
        .error {
            color: red;
        }
        label {
            display: block;
            margin-top: 0.5em;
        }
    </style>
</head>
<body>
    <h1>Nuevo cultivo</h1>

    <p><a href="index.php">← Volver al listado</a></p>

    <?php if (!empty($mensajeError)): ?>
        <p class="error">
            <?php echo htmlspecialchars($mensajeError, ENT_QUOTES, 'UTF-8'); ?>
        </p>
    <?php endif; ?>

    <form action="nuevo.php" method="post">
        <label>
            Nombre:
            <input
                type="text"
                name="nombre"
                value="<?php echo htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8'); ?>"
            >
        </label>
        <?php if (!empty($errores['nombre'])): ?>
            <p class="error"><?php echo htmlspecialchars($errores['nombre'], ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>

        <label>
            Tipo:
            <select name="tipo">
                <option value="">-- Selecciona un tipo --</option>
                <?php
                $tipos = ['Hortaliza', 'Fruto', 'Aromática', 'Legumbre', 'Tubérculo'];
                foreach ($tipos as $t):
                ?>
                    <option
                        value="<?php echo htmlspecialchars($t, ENT_QUOTES, 'UTF-8'); ?>"
                        <?php if ($tipo === $t) echo 'selected'; ?>
                    >
                        <?php echo htmlspecialchars($t, ENT_QUOTES, 'UTF-8'); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php if (!empty($errores['tipo'])): ?>
            <p class="error"><?php echo htmlspecialchars($errores['tipo'], ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>

        <label>
            Días hasta la cosecha:
            <input
                type="number"
                name="dias_cosecha"
                value="<?php echo htmlspecialchars((string)$dias_cosecha, ENT_QUOTES, 'UTF-8'); ?>"
            >
        </label>
        <?php if (!empty($errores['dias_cosecha'])): ?>
            <p class="error"><?php echo htmlspecialchars($errores['dias_cosecha'], ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>

        <p>
            <button type="submit">Guardar cultivo</button>
        </p>
    </form>
</body>
</html>
