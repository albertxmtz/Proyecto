<?php
// logic/cultivos.php
//
// Funciones de lógica de negocio: sin acceso a BD, sin HTML.

/**
 * Devuelve el ciclo del cultivo según sus días de cosecha.
 * Corto: <= 60, Medio: 61-120, Tardío: > 120.
 */
function cicloCultivo($dias)
{
    $dias = (int) $dias;

    if ($dias <= 60) {
        return 'Corto';
    } elseif ($dias <= 120) {
        return 'Medio';
    }

    return 'Tardío';
}

/**
 * Ordena el array de cultivos por dias_cosecha de menor a mayor.
 * $cultivos debe ser un array de arrays con la clave 'dias_cosecha'.
 */
function ordenarPorDias(&$cultivos)
{
    usort($cultivos, function ($a, $b) {
        $da = (int) $a['dias_cosecha'];
        $db = (int) $b['dias_cosecha'];
        if ($da === $db) {
            return 0;
        }
        return ($da < $db) ? -1 : 1;
    });
}

/**
 * Comprueba si el tipo de cultivo es uno de los permitidos.
 */
function esTipoValido($tipo)
{
    $tiposValidos = ['Hortaliza', 'Fruto', 'Aromática', 'Legumbre', 'Tubérculo'];
    return in_array($tipo, $tiposValidos, true);
}
