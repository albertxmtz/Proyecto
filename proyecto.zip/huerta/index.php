<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/logic/cultivos.php';

// Obtenemos los cultivos usando sentencia preparada.
// IMPORTANTE: no usamos mysqli_stmt_get_result para evitar problemas de compatibilidad.
$sql = "SELECT id, nombre, tipo, dias_cosecha FROM cultivos";
$stmt = mysqli_prepare($conexion, $sql);

$cultivos = [];

if ($stmt) {
    if (mysqli_stmt_execute($stmt)) {
        // Asociar variables a las columnas
        mysqli_stmt_bind_result($stmt, $id, $nombre, $tipo, $dias);

        // Recoger fila a fila
        while (mysqli_stmt_fetch($stmt)) {
            $cultivos[] = [
                'id'           => $id,
                'nombre'       => $nombre,
                'tipo'         => $tipo,
                'dias_cosecha' => $dias,
            ];
        }
    } else {
        error_log('Error al ejecutar SELECT de cultivos: ' . mysqli_stmt_error($stmt));
    }

    mysqli_stmt_close($stmt);
} else {
    error_log('Error al preparar SELECT de cultivos: ' . mysqli_error($conexion));
}

// Ordenamos por días de cosecha
ordenarPorDias($cultivos);

// Paginación manual (3 cultivos por página)
$porPagina     = 3;
$totalCultivos = count($cultivos);
$totalPaginas  = $totalCultivos > 0 ? ceil($totalCultivos / $porPagina) : 1;

$paginaActual = filter_input(INPUT_GET, 'pag', FILTER_VALIDATE_INT);
if ($paginaActual === false || $paginaActual === null || $paginaActual < 1) {
    $paginaActual = 1;
} elseif ($paginaActual > $totalPaginas) {
    $paginaActual = $totalPaginas;
}

$inicio         = ($paginaActual - 1) * $porPagina;
$cultivosPagina = array_slice($cultivos, $inicio, $porPagina);

$mensaje = filter_input(INPUT_GET, 'mensaje', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de cultivos</title>
    <style>
        table { border-collapse: collapse; width: 80%; margin-top: 1em; }
        th, td { border: 1px solid #ccc; padding: 0.5em; text-align: left; }
        .mensaje { color: green; }
    </style>
</head>
<body>
    <h1>Listado de cultivos</h1>

    <p><a href="nuevo.php">➕ Nuevo cultivo</a></p>

    <?php if (!empty($mensaje)): ?>
        <p class="mensaje">
            <?php echo htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8'); ?>
        </p>
    <?php endif; ?>

    <?php if (empty($cultivosPagina)): ?>
        <p>No hay cultivos registrados.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Días hasta la cosecha</th>
                    <th>Ciclo</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($cultivosPagina as $cultivo): ?>
                <tr>
                    <td><?php echo htmlspecialchars($cultivo['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($cultivo['nombre'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($cultivo['tipo'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($cultivo['dias_cosecha'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td>
                        <?php
                        echo htmlspecialchars(
                            cicloCultivo($cultivo['dias_cosecha']),
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ($totalPaginas > 1): ?>
            <p>
                Páginas:
                <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                    <?php if ($i === $paginaActual): ?>
                        <strong><?php echo $i; ?></strong>
                    <?php else: ?>
                        <a href="index.php?pag=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                    <?php if ($i < $totalPaginas) echo ' | '; ?>
                <?php endfor; ?>
            </p>
        <?php endif; ?>
    <?php endif; ?>

</body>
</html>
