<?php
// config/db.php
//
// Lee las credenciales desde .env y crea la conexión mysqli en $conexion.

$envPath = __DIR__ . '/../.env';

if (file_exists($envPath)) {
    $lineas = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lineas as $line) {
        $line = trim($line);

        // Saltar líneas vacías o comentarios (#)
        if ($line === '' || $line[0] === '#') {
            continue;
        }

        // clave=valor
        $partes = explode('=', $line, 2);
        if (count($partes) !== 2) {
            continue;
        }

        $key   = trim($partes[0]);
        $value = trim($partes[1]);

        if ($key !== '') {
            putenv("$key=$value");
        }
    }
}

// Credenciales obtenidas del entorno (.env)
$host       = getenv('DB_HOST') ?: 'localhost';
$usuario    = getenv('DB_USER') ?: 'root';
$contrasena = getenv('DB_PASS') ?: '';
$base_datos = getenv('DB_NAME') ?: 'huerta_db';

// Conexión
$conexion = mysqli_connect($host, $usuario, $contrasena, $base_datos);

if (!$conexion) {
    // No mostramos el error real al usuario, solo lo registramos
    error_log('Error de conexión a MySQL: ' . mysqli_connect_error());
    die('Error interno al conectar con la base de datos.');
}

// Charset recomendado
mysqli_set_charset($conexion, 'utf8mb4');
