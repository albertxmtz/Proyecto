<?php

$host = 'localhost';
$usuario = 'root';
$contrasena = 'abcd1234'; // en XAMPP por defecto está vacío
$base_datos = 'huerta_db';

$conexion = mysqli_connect($host, $usuario, $contrasena, $base_datos);

if (!$conexion) {
    die('Error de conexión a la base de datos: ' . mysqli_connect_error());
}

mysqli_set_charset($conexion, 'utf8mb4');
